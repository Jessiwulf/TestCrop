module se233.testcrop {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires javafx.swing;


    opens se233.testcrop to javafx.fxml;
    exports se233.testcrop;
}